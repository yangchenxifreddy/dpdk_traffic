See: https://github.com/memcached/memcached/wiki/DevelopmentRepos

It's worth repeating here, that the biggest contribution anyone can make is to
help run new releases! Any feedback we get is greatly appreciated. Hard to
know what to work on and what to prioritize if we don't hear from you :)

The easiest thing to do is to run the latest version on one machine in your
cluster sometimes. Then when you do need to upgrade, you should also have
confidence in a well tested version.
