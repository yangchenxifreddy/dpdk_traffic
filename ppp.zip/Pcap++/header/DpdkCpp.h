#pragma once
namespace pcpp
{

int DpdkEnter(int argc, char **argv);
}
