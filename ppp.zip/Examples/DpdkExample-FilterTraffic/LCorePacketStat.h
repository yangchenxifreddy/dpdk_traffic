#pragma once
#include "LockFreeQueue.h"
#include <unordered_map>


class SPktStat
{
private:
	uin32_t hashid;
	uint32_t pps;
	uint32_t bps;
public:
	SPktStat(uint32_t id):hashid(id),pps(0),bps(0);
	SPktStat(const SPktStat& stat)
	{
		hashid= stat.hashid;
		pps=stat.pps;
		bps=stat.bps;
	}
	
	SPktStat operator=(const SPktStat& stat)
	{
		hashid= stat.hashid;
		pps=stat.pps;
		bps=stat.bps;
		return *this;
	}

	inline uint32_t GetHashId(){return hashid;}
	inline uint32_t GetPPS(){return pps;}
	inline uint32_t GetBPS(){return bps;}

	inline uin32_t AddPPS(uint32_t a=1){pps+=a;return pps;}
	inline uin32_t AddBPS(uint32_t a=1){bps+=a;return bps;}

};


class PacketFeatureProc
{

	virtual void Proc100ms(){}

};

class PacketStatProc:public PacketFeatureProc
{
private:
	std::unordered_map<uint32_t,SPktStat>	m_pktStat;
	std::unordered_map<uint32_t,uint32_t> m_ipConn; 
	
	virtual void Proc100ms(){}
	
};


//单核处理包
class LCorePacketStat
{
private:
	LockFreeQueue<pcpp::Packet>* m_pktBuf;
	LockFreeQueue<pcpp::Packet>* m_sendWriteBuf;
	LockFreeQueue<SPktStat>* m_sendStatBuf;
public:
	LCorePacketStat(LockFreeQueue<pcpp::Packet>*pktbuf,
		LockFreeQueue<pcpp::Packet>*statbuf,
		LockFreeQueue<SPktStat>*writebuf)
	{
		m_pktBuf= pktbuf;
		m_sendWriteBuf= writebuf;
		m_sendStatBuf= statbuf;
	}
		
	virtual ~LCorePacketStat(){}
	void RunFunc()
	{
		SPktStat stat;
		pcpp::Packet pkt;
		
		while(1)
		{
			if(NULL== m_pktBuf)
			{
				std::cout<<"***error: lock queue is null "<<std::endl;
				return;
			}
		
			while(m_pktBuf->pop(pkt))
			{
				stat;

			}
		
//	        std::this_thread::sleep_for(std::chrono::seconds(1));
//			std::cout<<"LCorePacketStat::RunFunc"<<std::endl;
		}
	}
	void RunFuncA(const void *arg1, unsigned arg2)
	{
		std::cout<<"LCorePacketStat::RunFuncA"<<std::endl;
	}
	
};




