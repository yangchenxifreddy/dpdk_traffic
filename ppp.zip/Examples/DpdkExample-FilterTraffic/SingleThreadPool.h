
#include <thread>
#include <vector>
#include <iostream>
#include <cstdint>
#include <chrono>


#define THREAD_MAXNUM 64
template<class TFunc>
class SingleThreadPool {
private:
	std::string m_poolName;
	uint32_t m_threadNum;
	TFunc* tfunc;
	std::thread m_threadPool[THREAD_MAXNUM];
public:
	SingleThreadPool(std::string namestr):m_poolName(namestr),m_threadNum(0),tfunc(NULL)
	{	
			
	}
	
	SingleThreadPool(std::string namestr,TFunc* tf):m_poolName(namestr),m_threadNum(0),tfunc(NULL)
	{		
		tfunc= tf;
	}
	virtual ~SingleThreadPool(){}
	void RunFunc() 
	{
		if(NULL!= tfunc)
			return tfunc->RunFunc();
	}
	
	void RunFuncA(const void *arg1, unsigned arg2)
	{
		 if(NULL!=tfunc)
			 return tfunc->RunFuncA(arg1,arg2);
	}
	void CreateThread(uint32_t num= 1) 
	{
		for(uint32_t t=0;t<num;++t)
		{
			if((THREAD_MAXNUM-1)<= m_threadNum)
				return;
			m_threadPool[m_threadNum++]= std::thread(&SingleThreadPool::RunFunc, this);
		}
	}
	
	void CreateThreadA(const char *arg1, unsigned arg2) 
	{
	
		if((THREAD_MAXNUM-1)<= m_threadNum)
		return ;
		m_threadPool[m_threadNum++]=(std::thread(&SingleThreadPool::RunFuncA, this, arg1, arg2));
	}

	void ThreadJoin()
	{
		for(uint32_t t=0;t<m_threadNum;++t )
			m_threadPool[t].join();
	}
	
	void ThreadDetach()
	{
		for(uint32_t t=0;t<m_threadNum;++t )
			m_threadPool[t].detach();
	}
};

