#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/queue.h>
#include <netinet/in.h>
#include <setjmp.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <signal.h>
#include <stdbool.h>


#include "DpdkCpp.h"
#include "SingleThreadPool.h"

int main(int argc, char **argv)
{
	char **argvlist;
	
	unsigned int paramid= 0,argcsize= 10;
uint32_t	l2fwd_enabled_port_mask= 0x01;	
uint32_t	l2fwd_rx_queue_per_lcore= 0x04;

	argvlist= (char**)malloc(argcsize* sizeof(char*));
	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"TrafficMonitor");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-c");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	sprintf(argvlist[paramid++],"%d",7);


	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-n");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	sprintf(argvlist[paramid++],"%d",4);

// 
	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"--");


	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-q");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	sprintf(argvlist[paramid++],"%d",l2fwd_rx_queue_per_lcore);


	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	strcpy(argvlist[paramid++],"-p");

	argvlist[paramid]= (char*)malloc(16*sizeof(char));
	sprintf(argvlist[paramid++],"%d",l2fwd_enabled_port_mask);
	printf("  %\n\n ");
	int i=0;
	while(i<argcsize)
	{
	//for(int i=0;i<argcsize;++i)
	printf("  %s  ",argvlist[i++]);
	}
	printf("  %\n\n ");
	LCorePacketStat* corestat= new LCorePacketStat();
	
	SingleThreadPool<LCorePacketStat> *threadpool= new SingleThreadPool<LCorePacketStat>("stat",corestat);

	threadpool->CreateThread(4);

	threadpool->ThreadJoin();
 
	  delete corestat;

	return pcpp::DpdkEnter(argcsize,argvlist);
}

